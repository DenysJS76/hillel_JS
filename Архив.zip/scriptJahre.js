// Завдання № 2 Лекції 4 (Домашне завдання 2)

let myYear = +prompt ('Введіть рік:');
let realDate = new  Date (myYear, 1, 29).getDate ();
if (realDate == 29) alert ('Так цей рік високосний'); else alert ('Ні рік не високосний');
