 // Завдання № 1 Лекції 4 (Домашне завдання 2)

    const userInput = prompt('Введіть число: ');//Введення числа користувачем
    const parseInput = parseInt(userInput); // створення змінної зі значенням, який ввід користувач

    if ((parseInput % 5 == 0) && (parseInput % 3 == 0)) {// Умова за якою введене користувачем число ділеться на 3 та на 5, вертає на екран 'FizzBuzz'
		console.log('FizzBuzz');
	}
    
    else if ((parseInput % 3 == 0) && (parseInput % 5 != 0)) { //Умова за якою введене користувачем число ділеться на 3 та не ділеться на 5, вертає на екран 'Fizz'
		console.log('Fizz');
	}

	 else if ((parseInput % 5 == 0) && (parseInput % 3 != 0)){ //Умова за якою введене користувачем число ділеться на 3 та не ділеться на 5, вертає на екран 'Buzz'
		console.log('Buzz');
	}   

    else if ((parseInput % 3 != 0) && (parseInput % 5 != 0)) {
		console.log('Число не ділиться на 3 або на 5 без залишку'); // Не маэ цілого ділення
    }