// stub
function reverseString(str) {
  return str;
}

// test
reverseString("hello");