const userInput = prompt('Введіть число: ');//Введення числа користувачем
const num = parseInt(userInput); // створення змінної зі значенням, який ввів користувач

let i = 2;
      let flag = 1;
      const sq = Math.sqrt(num);
      while (i <= sq) {
        if (num % i === 0) {
          flag = 0;
          console.log ('Число ' + num + ' не є простим числом');
          break;
        }
        i +=1;
      }
      if (flag == 1)  
       console.log ('Число '+ num + ' є простим числом');



