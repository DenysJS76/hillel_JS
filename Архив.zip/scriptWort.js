// Завдання № 3 Лекції 4 (Домашне завдання 2)

let age = +prompt ('Введіть Ваш вік:');
let count = age;
let result = " "

if (count >=10 && count <= 20) {
    result = "років"
} else {
    count = age % 10
    if (count == 1) {
        result = "рік"
    } else if (count >=2 && count <= 4){
        result = "роки"
    } else {
        result = "років"
    }
} 
console.log("Вам " + age + " " + result)
